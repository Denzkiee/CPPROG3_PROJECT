



let a = nu
let b = 1

return checker()

function checker(){
    if (a < b)
        alert ("true")

    else
    alert ("False")
    
}